import { Component, OnChanges, OnInit } from '@angular/core';
import { BookInterface } from './book.interface';
import { BookDataService } from './book-data.service';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit, OnChanges {
  datum = new Date();

  imageWidth = 50;
  coverIsVisible = true;
  searchValue = '';

  books = [];

  // _bookDataService: BookDataService

  constructor(private _bookDataService: BookDataService) {
    console.log('constructor');
    // this._bookDataService = _bookDataService;
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.books = this._bookDataService.getBooks();
  }
  ngOnChanges(): void {
    console.log('ngOnChanges');
  }

  toggleCover() {
    this.coverIsVisible = !this.coverIsVisible;
  }

  newRating(event) {
    console.log('BookList received event ', event);
  }
}
