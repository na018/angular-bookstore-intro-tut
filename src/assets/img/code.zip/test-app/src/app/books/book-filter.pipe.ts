import { Pipe, PipeTransform } from '@angular/core';
import { BookInterface } from './book.interface';
import { isUndefined } from 'util';

@Pipe({
  name: 'bookfilter'
})
export class BookFilterPipe implements PipeTransform {
  transform(books: BookInterface[], filterValue: string): BookInterface[] {
    const filterwert = (filterValue || '').toLocaleLowerCase();

    return books.filter(
      book => book.title.toLocaleLowerCase().indexOf(filterwert) >= 0
    );
  }
}
