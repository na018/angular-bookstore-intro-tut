export interface BookInterface {
  isbn: string;
  title: string;
  coverUrl: string;
  price: number;
  rating: number;
  comment?: string;
}
