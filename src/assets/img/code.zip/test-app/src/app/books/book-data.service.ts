import { BookInterface } from './book.interface';
import { Injectable } from '@angular/core';

@Injectable()
export class BookDataService {
  getBooks(): BookInterface[] {
    return [
      {
        isbn: '12345667789',
        title: 'Angular 4 rocks :-)',
        coverUrl:
          'https://images-eu.ssl-images-amazon.com/images/I/514Q+CZgjjL._AC_US218_.jpg',
        price: 5.39,
        rating: 4.5
      },
      {
        isbn: '12345667998',
        title: 'Angular 5 rocks even more',
        coverUrl:
          'https://images-eu.ssl-images-amazon.com/images/I/51SRFX--KdL._AC_US218_.jpg',
        price: 6.39,
        comment: 'blabla',
        rating: 4.7
      }
    ];
  }
}
