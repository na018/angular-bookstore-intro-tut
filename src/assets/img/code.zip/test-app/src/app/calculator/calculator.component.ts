import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html'
})
export class CalculatorComponent {
  x = '';
  y = '';
  z = 0;

  add() {
    this.z = parseFloat(this.x) + parseFloat(this.y);
  }

  subtract() {
    this.z = parseFloat(this.x) - parseFloat(this.y);
  }

  clear() {
    this.x = '';
    this.y = '';
    this.z = 0;
  }
}
