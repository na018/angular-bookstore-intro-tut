import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter
} from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html'
})
export class RatingComponent implements OnInit, OnChanges {
  @Input() stars: number;

  @Input() id: string;

  @Output() notify: EventEmitter<string> = new EventEmitter<string>();
  starwidth = 0;

  constructor() {}

  ngOnInit() {
    this.recalc();
  }

  ngOnChanges(): void {
    this.recalc();
  }

  recalc() {
    this.starwidth = this.stars / 5.0 * 100;
  }

  clickedOnStars() {
    this.notify.emit(`id ${this.id} was clicked`);
  }
}
